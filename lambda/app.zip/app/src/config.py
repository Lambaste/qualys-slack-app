#query = 'SELECT title, ip, dns, cve_list FROM "AwsDataCatalog"."qlys_host_list_db"."qlys_hdl_enrichedwithssvcv2" ORDER By dns ASC LIMIT 10;'
query = 'SELECT title, ip, dns, cve_list FROM "AwsDataCatalog"."qlys_host_list_db"."qlys_hdl_enrichedwithssvcv2";'
database = 'qlys_host_list_db'
output = 's3://gary-s3-athena/'