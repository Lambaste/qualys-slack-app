# Don't add async module imports here
from ..starlette.handler import SlackRequestHandler

__all__ = [
    "SlackRequestHandler",
]
